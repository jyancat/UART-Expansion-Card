# UART Expansion Card
Design files for the UART expansion card, please note this is a tested and working expansion card. Licensed under CERN-OHL-S-2.0. Uses the CH340C with switchable power and logic levels (5V and 3V3) Please note that the files in the 3D Printer Files directory are not finalised. Part numbers in the BOM may be diffent to what you do recieve due to supply and cost changes.
